<?php $__env->startSection('header'); ?>
	<div class="section-header">
    <h1>Dashboard</h1>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <div class="card card-statistic-1">
        <div class="card-icon bg-danger">
            <i class="far fa-newspaper"></i>
        </div>
        <div class="card-wrap">
            <div class="card-header">
            <h4>Total Blog</h4>
            </div>
            <div class="card-body">
            <?php echo e($blog_count); ?>

            </div>
        </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <div class="card card-statistic-1">
        <div class="card-icon bg-warning">
            <i class="fas fa-comment"></i>
        </div>
        <div class="card-wrap">
            <div class="card-header">
            <h4>FAQ</h4>
            </div>
            <div class="card-body">
            <?php echo e($faq_count); ?>

            </div>
        </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
        <div class="card card-statistic-1">
        <div class="card-icon bg-success">
            <i class="fas fa-box"></i>
        </div>
        <div class="card-wrap">
            <div class="card-header">
            <h4>Package</h4>
            </div>
            <div class="card-body">
            <?php echo e($package_count); ?>

            </div>
        </div>
        </div>
    </div>                  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/diginomik/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>