<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Digifolium, mitra tepercaya bagi penjual dan pemilik merek di Indonesia. Dapatkan jasa kelola dan optimasi toko online di berbagai marketplace untuk meningkatkan penjualan produk Anda.">
    <meta name="keywords" content="Optimasi Toko Online, Manajemen Marketplace, Jasa Kelola Toko, Optimalisasi Penjualan">


    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/light_logo_1.png')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/main.css')); ?>">

    <!-- PLUGIN -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <title>Jasa Kelola dan Optimasi Toko Online di Marketplace - Digifolium</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary-new fixed-top">
        <div class="container">
        <a class="navbar-brand" href="#header">
            <img src="<?php echo e(asset('assets/images/light_logo_1.png')); ?>" alt="" srcset="" height="80">
        </a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="#tentangkami" class="nav-link  ml-0 ml-md-4" href="#">Tentang Kami <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a href="#mengapakami" class="nav-link  ml-0 ml-md-4" href="#"> Mengapa Memiliki Kami?</a>
                </li>
                <li class="nav-item">
                    <a href="#layananjasa" class="nav-link  ml-0 ml-md-4" href="#">Layanan Jasa</a>
                </li>
                <li class="nav-item">
                    <a href="#faq" class="nav-link  ml-0 ml-md-4" href="#">FAQ</a>
                </li>
                <li class="nav-item">
                    <a href="#blog" class="nav-link ml-0 ml-md-4" href="#">Blog</a>
                </li>
                <li class="nav-item">
                    <a href="https://api.whatsapp.com/send?phone=628116338890&text=Halo%20admin%20Diginomik%2C%20saya%20ingin%20tahu%20info%20detail%20mengenai%20layanan%20jasanya" class="btn btn-consult-now ml-0 ml-md-4" target="_blank">Hubungi Kami</a>
                </li>
            </ul>
        </div>
        </div>
    </nav>
    
    <div id="header"></div>
    <section class="section-header">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 img-wrapper d-none d-md-block">
                    <img src="<?php echo e(asset('assets/images/img_banner.png')); ?>" alt="">
                </div>
                <div class="col-12 col-md-6 text-wrapper pt-0 pt-md-5">
                    <div class="title"> <span style="color : #FF9536">Mitra tepercaya</span> untuk optimasi toko online di Indonesia.</div>
                    <div class="subtitle">Mitra andal untuk optimasi toko online di Indonesia, meningkatkan peluang penjualan produk Anda secara signifikan.</div>
                    <a href="#tentangkami" class="btn btn-learnmore">Pelajari Selengkapnya</a>
                </div>
            </div>
        </div>
    </section>

    <div id="tentangkami"></div>
    <section class="section-about-us" data-aos="fade-up" data-aos-duration="1000">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-5">
                    <div class="title">Tentang Kami</div>
                    <div class="subtitle">
                    Selama lebih dari 3 tahun, kami telah menjadi mitra tepercaya bagi penjual dan pemilik merek di seluruh Indonesia. Kami menawarkan jasa kelola dan optimasi toko online di berbagai marketplace. Dengan bantuan kami, Anda dapat meningkatkan peluang penjualan produk Anda, bahkan mencapai ratusan bahkan ribuan unit. Percayakan optimasi toko Anda kepada Digifolium untuk mengoptimalkan kinerja toko online Anda dan memperluas jangkauan pasar Anda.
                    <br><br>
                    Kami adalah perusahaan startup yang berbasis di Bogor, telah beroperasi sejak 2020. Fokus kami adalah pada jasa optimasi marketplace di Indonesia, termasuk manajemen toko dan pengiklanan di platform seperti Shopee, Tokopedia, Lazada, dan TikTokShop. Kami hadir untuk mendukung Brand Owner dan Business Owner dalam meningkatkan penjualan mereka di berbagai platform marketplace dengan strategi yang terbukti dan terpercaya.
                    <br><br>
                    Tim kami selalu siap mendukung Anda dalam mengatasi tantangan dan pertanyaan yang muncul sepanjang perjalanan meningkatkan penjualan Anda.
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-8 about-wrapper">
                   <div class="row">
                        <div class="col-12 col-md-6 about-card-item">
                           <div class="number">1.</div>
                           <div class="title">Mengapa Memilih Diginomik?</div>
                           <div class="subtitle">Diginomik, pemimpin pasar berpengalaman, membantu brand UMKM di Indonesia, memperkuat toko online Anda di marketplace lokal.</div>
                        </div>
                        <div class="col-12 col-md-6 about-card-item">
                            <div class="number">2.</div>
                            <div class="title">Energik, Inovatif, dan Bertekad</div>
                            <div class="subtitle">semangat tak kenal lelah, bantu hadapi tantangan, capai impian. Bersama, tidak ada yang tidak mungkin.</div>
                        </div>
                        <div class="col-12 col-md-6 about-card-item">
                            <div class="number">3.</div>
                            <div class="title">Keamanan dan Kepuasan Anda Prioritas Kami</div>
                            <div class="subtitle">Keamanan akun dan data toko utama. Fokus pada bisnis, pelayanan ramah, dan responsif untuk kepuasan Anda.</div>
                        </div>
                        <div class="col-12 col-md-6 about-card-item">
                            <div class="number">4.</div>
                            <div class="title">Mengapa Memilih Diginomik?</div>
                            <div class="subtitle">Diginomik, pemimpin pasar berpengalaman, membantu brand UMKM di Indonesia, memperkuat toko online Anda di marketplace lokal.</div>
                        </div>
                   </div>
                </div>
                <div class="col-12 col-md-4">
                   <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/banner_about.jpg')); ?>" alt="">
                   </div>
                </div>
            </div>
        </div>
    </section>

    <div id="mengapakami"></div>
    <section class="section-usp" data-aos="fade-up" data-aos-duration="1000">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-3 text-wrapper mb-5 mb-md-0">
                   <div class="title">Mengapa Memilih Diginomik? 🚀  </div>
                   <div class="subtitle">Dengan bantuan kami, Anda dapat meningkatkan peluang penjualan produk Anda.</div>
                </div>
                <div class="col-12 col-md-3 usp-wrapper mb-5 mb-md-0">
                    <div class="img-wrapper">
                        <img src="<?php echo e(asset('assets/images/icon_layer.svg')); ?>" alt="">
                    </div>
                    <div class="title">Berpengalaman</div>
                    <div class="subtitle">Dikerjakan oleh tim yang telah memiliki pengalaman luas dalam membantu banyak brand UMKM di Indonesia. Kami memahami pasar lokal dan memiliki pengetahuan yang mendalam dalam mengoptimalkan toko online Anda.</div>
                </div>
                <div class="col-12 col-md-3 usp-wrapper mb-5 mb-md-0">
                    <div class="img-wrapper">
                        <img src="<?php echo e(asset('assets/images/icon_layer.svg')); ?>" alt="">
                    </div>
                    <div class="title">Berkualitas</div>
                    <div class="subtitle">Kami tidak hanya menyediakan jasa, tetapi juga strategi. Anda dapat berkonsultasi dengan tim Diginomik untuk merancang toko sesuai dengan keinginan Anda, sehingga mencapai hasil yang diinginkan.</div>
                </div>
                <div class="col-12 col-md-3 usp-wrapper mb-5 mb-md-0">
                    <div class="img-wrapper">
                        <img src="<?php echo e(asset('assets/images/icon_layer.svg')); ?>" alt="">
                    </div>
                    <div class="title">Kepuasan Pelanggan</div>
                    <div class="subtitle">Pelayanan kami selalu ramah dan responsif, baik sebelum maupun sesudah kolaborasi. Prioritas utama kami adalah memastikan Anda merasa puas dengan layanan yang kami berikan, karena kepuasan Anda adalah tujuan utama kami.</div>
                </div>
            </div>
        </div>
    </section>

    <div id="layananjasa"></div>
    <section class="section-package" data-aos="fade-up" data-aos-duration="1000">
        <div class="container">
            <div class="header-title">
                <div class="title">Pilih Layanan Jasa Kami</div>
            </div>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-12 col-md-4 package-card-wrapper">
                    <div class="card-item">
                        <div class="title"><?php echo e($item->title); ?></div>
                        <div class="subtitle"><?php echo e($item->subtitle); ?></div>
                        <?php if($item->discount == 0): ?>
                        <div class="final-price">Rp<?php echo e(number_format($item->final_price)); ?></div>
                        <?php else: ?>
                        <div class="discount-wrapper">
                            <div class="price">Rp<?php echo e(number_format($item->price)); ?></div>
                            <div class="badge badge-success discount">Diskon <?php echo e($item->discount); ?>%</div>
                        </div>
                        <div class="final-price">Rp<?php echo e(number_format($item->final_price)); ?></div>
                        <?php endif; ?>
                        <a href="https://api.whatsapp.com/send?phone=628116338890&text=Halo%20admin%20Diginomik%2C%20saya%20ingin%20tahu%20info%20detail%20mengenai%20layanan%20jasanya" class="btn btn-consult" target="_blank">Hubungi Kami</a>
                        <div class="benefit-wrapper">
                            <?php
                                $benefit = App\Models\Benefit::where('package_id',$item->id)->get();
                            ?>
                            <?php $__empty_2 = true; $__currentLoopData = $benefit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <div class="benefit-item">
                                <?php if($item->type == 'include'): ?>
                                <img src="<?php echo e(asset('assets/images/check_1.svg')); ?>" alt="">
                                <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/wrong_1.svg')); ?>" alt="">
                                <?php endif; ?>
                                <div class="title"><?php echo e($item->benefit); ?></div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            <div class="benefit-item">
                               No Benefit
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center">
                    No Package Available
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="section-kerjasama" data-aos="fade-up" data-aos-duration="1000">
        <div class="container">
            <div class="header-title">
                <div class="title">Partner Kami</div>
                <div class="subtitle">UMKM yang Telah Bekerja Sama Dengan Kami</div>
            </div>
            <div class="logo-wrapper">
                <div class="row">
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy-logo-5b.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="section-beforeafter" data-aos="fade-up" data-aos-duration="1000">
        <div class="container">
            <div class="header-title">
                <div class="title">Hasil Kerja Kami</div>
                <div class="subtitle">Beberapa Hasil Iklan yang Sudah Kami Kerjakan</div>
            </div>
            <div class="logo-wrapper">
                <div class="row">
                    <div class="col-12 col-md-6 mb-5">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy_hasilkerja.jpg')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-12 col-md-6 mb-5">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('assets/images/dummy_hasilkerja.jpg')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div id="faq"></div>
    <section class="section-faq" data-aos="fade-up" data-aos-duration="1000">
        <div class="container">
            <div class="header-title">
                <div class="title">FAQ</div>
                <div class="subtitle">Pertanyaan yang Sering Diajukan: Temukan Solusi dan Informasi Lengkap untuk Kebutuhan Anda</div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="faq-wrapper">
                        <div class="accordion" id="accordionDesktop">
                            <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-faq-item">
                                <div class="card-header" id="heading<?php echo e($key); ?>">
                                    <h2 class="mb-0">
                                        <a class="accordion-title <?php echo e($key == 0 ? '' : 'collapsed'); ?>" data-toggle="collapse" data-target="#collapse<?php echo e($key); ?>" aria-expanded="<?php echo e($key == 0 ? 'true' : 'false'); ?>" aria-controls="collapse<?php echo e($key); ?>">
                                        <?php echo $item->question; ?>

                                        </a>
                                    </h2>
                                </div>
                                <div id="collapse<?php echo e($key); ?>" class="collapse" aria-labelledby="heading<?php echo e($key); ?>" data-parent="#accordionDesktop">
                                    <div class="card-body">
                                        <?php echo $item->answer; ?>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
           </div>
           <div class="footer-title">
                <div class="title">Tunggu Apa Lagi?</div>
                <div class="subtitle">Jika semua pertanyaanmu sudah terjawab, ayo mulai kolaborasi bersama tim hebat kami!</div>
                <a href="https://api.whatsapp.com/send?phone=628116338890&text=Halo%20admin%20Diginomik%2C%20saya%20ingin%20tahu%20info%20detail%20mengenai%20layanan%20jasanya" class="btn btn-consult-now ml-0 ml-md-4" target="_blank">Hubungi Kami</a>
            </div>
        </div>
    </section>

    <div id="blog"></div>
    <section class="section-blog" data-aos="fade-up" data-aos-duration="1000">
        <div class="container">
            <div class="header-title">
                <div class="title">Blog</div>
                <div class="subtitle">Tetap Terinformasi dan Terinspirasi dengan Artikel Terbaru Kami tentang Tren dan Strategi Media Sosial</div>
            </div>
            <div class="blog-wrapper">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-12 col-md-4 blog-item mb-5">
                        <a href="<?php echo e(route('detail_blog',$item->id)); ?>">
                            <div class="img-wrapper">
                                <img src="<?php echo e(asset('upload/'.$item->img)); ?>" alt="">
                            </div>
                            <div class="title"><?php echo e($item->title); ?></div>
                            <div class="subtitle"><?php echo $item->content; ?></div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12 text-center">
                        No Blog Available
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <div id="hubungikami"></div>
    <section class="section-contact-us">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="title">Jadilah satu dari ratusan UMKM sukses yang telah bergabung dengan kami</div>
                    <a href="https://api.whatsapp.com/send?phone=628116338890&text=Halo%20admin%20Diginomik%2C%20saya%20ingin%20tahu%20info%20detail%20mengenai%20layanan%20jasanya" class="btn btn-consult-now ml-0 ml-md-4" target="_blank">Hubungi Kami</a>
                </div>
            </div>
        </div>
    </section>


    <footer class="section-footer">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                    <img src="<?php echo e(asset('assets/images/light_logo_1.png')); ?>" alt="" srcset="" width="200">
                    <br>
                    <div class="address-title">Alamat Kantor</div>
                    <div class="address">
                    JL. Kol Masturi 591, Cimahi, Cimahi Tengah - West Java 40525
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                    <div class="sosmed-title">Social Media</div>
                    <div class="sosmed-wrapper">
                        <img src="<?php echo e(asset('assets/images/facebook.svg')); ?>" alt="" width="20">
                        <a href="#" class="sosmed">Facebook</a>
                    </div>
                    <br>
                    <div class="sosmed-wrapper">
                        <img src="<?php echo e(asset('assets/images/twitter.svg')); ?>" alt="" width="15">
                        <a href="#" class="sosmed">Twitter</a>
                    </div>
                    <br>
                    <div class="sosmed-wrapper">
                        <img src="<?php echo e(asset('assets/images/instagram.svg')); ?>" alt="" width="15">
                        <a href="#" class="sosmed">Instagram</a>
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                <div class="contact-title">Contact Us</div>
                    <div class="contact-wrapper">
                        <img src="<?php echo e(asset('assets/images/whatsapp.svg')); ?>" alt="" width="20">
                        <a href="#" class="contact">Whatsapp</a>
                    </div>
                    <br>
                    <div class="contact-wrapper">
                        <img src="<?php echo e(asset('assets/images/email.svg')); ?>" alt="" width="20">
                        <a href="#" class="contact">Email</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- PLUGIN -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            const target = document.querySelector(this.getAttribute('href'));
            const offset = 100; // Atur offset margin atas yang diinginkan di sini

            window.scrollTo({
                top: target.offsetTop - offset,
                behavior: 'smooth'
            });
        });
    });
</script>
  </body>
</html><?php /**PATH /Applications/MAMP/htdocs/diginomik/resources/views/user/index.blade.php ENDPATH**/ ?>