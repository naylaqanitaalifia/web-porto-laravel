<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Admin Site</title>

  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo e(asset('admin-template/modules/bootstrap/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin-template/modules/fontawesome/css/all.min.css')); ?>">

  <!-- CSS Libraries -->

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('admin-template/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin-template/css/components.css')); ?>">


<body>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="index.html">Stisla</a>
          </div>
          <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">St</a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li class="<?php echo e(request()->is('admin/dashboard*') ? 'nav-item active' : 'nav-item'); ?>">
                <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a>
            </li>
            <li class="<?php echo e(request()->is('admin/faq*') ? 'nav-item active' : 'nav-item'); ?>">
                <a class="nav-link" href="<?php echo e(route('faq.index')); ?>"><i class="fa fa-comment"></i> <span>FAQ Management</span></a>
            </li>
            <li class="<?php echo e(request()->is('admin/blog*') ? 'nav-item active' : 'nav-item'); ?>">
                <a class="nav-link" href="<?php echo e(route('blog.index')); ?>"><i class="fa fa-newspaper"></i> <span>Blog Management</span></a>
            </li>
            <li class="<?php echo e(request()->is('admin/package*') ? 'nav-item active' : 'nav-item'); ?>">
                <a class="nav-link" href="<?php echo e(route('package.index')); ?>"><i class="fa fa-box"></i> <span>Package Management</span></a>
            </li>
            <li>
            <form id="logout-form" action="<?php echo e(route('admin_logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fa fa-door-closed"></i> 
                    <span>Logout</span>
                </a>
            </li>
            </aside>
      </div>

      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <?php echo $__env->yieldContent('header'); ?>
          <div class="section-body">
          <?php echo $__env->yieldContent('content'); ?>
          </div>
        </section>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>

  <!-- General JS Scripts -->
  <script src="<?php echo e(asset('admin-template/modules/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-template/modules/popper.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-template/modules/tooltip.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-template/modules/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-template/modules/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-template/modules/moment.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-template/js/stisla.js')); ?>"></script>
  
  <!-- JS Libraies -->

  <!-- Page Specific JS File -->
  <script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>
  <script>
    ClassicEditor
        .create(document.querySelector('#editor'))
        .catch(error => {
            console.error(error);
        });
  </script>

<script>
    ClassicEditor
        .create(document.querySelector('#editor1'))
        .catch(error => {
            console.error(error);
        });
  </script>
  
  <!-- Template JS File -->
  <script src="<?php echo e(asset('admin-template/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(asset('admin-template/js/custom.js')); ?>"></script>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
      <?php if(session('success')): ?>
          Swal.fire('Sukses', '<?php echo e(session('success')); ?>', 'success');
      <?php endif; ?>

      <?php if(session('error')): ?>
          Swal.fire('Error', '<?php echo e(session('error')); ?>', 'error');
      <?php endif; ?>
      
  </script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
        const deleteButtons = document.querySelectorAll('.delete-btn');

        deleteButtons.forEach(button => {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                const form = this.closest('form');

                Swal.fire({
                    title: 'Anda yakin?',
                    text: "Tindakan ini tidak dapat dikembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Ya, hapus!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    });
</script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/diginomik/resources/views/template/main.blade.php ENDPATH**/ ?>