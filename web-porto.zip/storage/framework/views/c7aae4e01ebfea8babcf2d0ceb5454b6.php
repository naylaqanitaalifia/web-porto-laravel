<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Digifolium, mitra tepercaya bagi penjual dan pemilik merek di Indonesia. Dapatkan jasa kelola dan optimasi toko online di berbagai marketplace untuk meningkatkan penjualan produk Anda.">
    <meta name="keywords" content="Optimasi Toko Online, Manajemen Marketplace, Jasa Kelola Toko, Optimalisasi Penjualan">


    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/light_logo_1.png')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/main.css')); ?>">

    <!-- PLUGIN -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <title>Jasa Kelola dan Optimasi Toko Online di Marketplace - Digifolium</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary-new fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#header">
                <img src="<?php echo e(asset('assets/images/light_logo_1.png')); ?>" alt="" srcset="" height="80">
            </a>
        </div>
    </nav>
    
    <section class="section-breadcrumb">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Landing Page</a></li>
                <!-- <li class="breadcrumb-item"><a href="#">Library</a></li> -->
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($blog->title); ?></li>
                </ol>
            </nav>
            </div>
    </section>

    <section class="section-detail-blog">
        <div class="container">
            <div class="title"><?php echo e($blog->title); ?></div>
            <div class="subtitle"><?php echo e($blog->author); ?></div>
            <div class="img-wrapper">
                <img src="<?php echo e(asset('upload/'.$blog->img)); ?>" alt="">
            </div>
            <div class="review">
                <?php echo $blog->content; ?>

            </div>
        </div>
    </section>


    <footer class="section-footer">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                    <img src="<?php echo e(asset('assets/images/light_logo_1.png')); ?>" alt="" srcset="" width="200">
                    <br>
                    <div class="address-title">Alamat Kantor</div>
                    <div class="address">
                    JL. Kol Masturi 591, Cimahi, Cimahi Tengah - West Java 40525
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                    <div class="sosmed-title">Social Media</div>
                    <div class="sosmed-wrapper">
                        <img src="<?php echo e(asset('assets/images/facebook.svg')); ?>" alt="" width="20">
                        <a href="#" class="sosmed">Facebook</a>
                    </div>
                    <br>
                    <div class="sosmed-wrapper">
                        <img src="<?php echo e(asset('assets/images/twitter.svg')); ?>" alt="" width="15">
                        <a href="#" class="sosmed">Twitter</a>
                    </div>
                    <br>
                    <div class="sosmed-wrapper">
                        <img src="<?php echo e(asset('assets/images/instagram.svg')); ?>" alt="" width="15">
                        <a href="#" class="sosmed">Instagram</a>
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                <div class="contact-title">Contact Us</div>
                    <div class="contact-wrapper">
                        <img src="<?php echo e(asset('assets/images/whatsapp.svg')); ?>" alt="" width="20">
                        <a href="#" class="contact">Whatsapp</a>
                    </div>
                    <br>
                    <div class="contact-wrapper">
                        <img src="<?php echo e(asset('assets/images/email.svg')); ?>" alt="" width="20">
                        <a href="#" class="contact">Email</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- PLUGIN -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            const target = document.querySelector(this.getAttribute('href'));
            const offset = 100; // Atur offset margin atas yang diinginkan di sini

            window.scrollTo({
                top: target.offsetTop - offset,
                behavior: 'smooth'
            });
        });
    });
</script>
  </body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/diginomik/resources/views/user/detail_blog.blade.php ENDPATH**/ ?>