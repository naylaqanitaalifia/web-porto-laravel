<?php $__env->startSection('header'); ?>
	<div class="section-header">
    <h1>Edit Package</h1>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <a href="<?php echo e(route('package.index')); ?>" class="btn btn-warning">Kembali ke Package List</a>
      </div>
      <form action="<?php echo e(route('package.update',$package->id)); ?>" method="post" enctype="multipart/form-data" id="inputForm">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
            <div class="card-body">
              <div class="form-group row mb-4">
                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Title</label>
                <div class="col-sm-12 col-md-7">
                  <input type="text" class="form-control" name="title" required value="<?php echo e($package->title); ?>">
                </div>
              </div>
              <div class="form-group row mb-4">
                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Subtitle</label>
                <div class="col-sm-12 col-md-7">
                  <input type="text" class="form-control" name="subtitle" required value="<?php echo e($package->subtitle); ?>">
                </div>
              </div>
              <div class="form-group row mb-4">
                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Price</label>
                <div class="col-sm-12 col-md-7">
                  <input type="number" class="form-control" name="price" required value="<?php echo e($package->price); ?>">
                </div>
              </div>
              <div class="form-group row mb-4">
                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Discount (Opsional)</label>
                <div class="col-sm-12 col-md-7">
                  <input type="number" class="form-control" name="discount" required value="<?php echo e($package->discount); ?>">
                </div>
              </div>
              <div class="form-group row mb-4">
                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Status</label>
                <div class="col-sm-12 col-md-7">
                  <select class="form-control" name="status">
                  <?php if($package->status == 'active'): ?>
                      <option value="active" selected>Active</option>
                      <option value="unactive">Unactive</option>
                  <?php elseif($package->status == 'unactive'): ?>
                      <option value="active">Active</option>
                      <option value="unactive" selected>Unactive</option>
                  <?php endif; ?>
                </select>
                </div>
              </div>
             
            </div>

            <div class="card-body" id="book_fields">
              <div class="form-group row mb-4">
                  <h2 class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Benefit Package</h2>
              </div>
              <?php $__currentLoopData = $benefitPackage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group row mb-5">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Item</label>
                    <div class="col-sm-12 col-md-2">
                        <select class="form-control" name="benefit[<?php echo e($key); ?>][type]" required>
                            <?php if($benefit->type == 'include'): ?>
                                <option value="include" selected>Include</option>
                                <option value="exclude">Exclude</option>
                            <?php elseif($benefit->type == 'exclude'): ?>
                                <option value="include">Include</option>
                                <option value="exclude" selected>Exclude</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-sm-12 col-md-4">
                        <input type="text" class="form-control" name="benefit[<?php echo e($key); ?>][benefit]" required value="<?php echo e($benefit->benefit); ?>">
                    </div>
                    <div class="col-sm-12 col-md-2">
                        <?php if($key == 0): ?>
                        <button type="button" class="btn btn-primary" onclick="addBenefit()">Tambah Benefit</button>
                        <?php elseif($key > 0): ?>
                        <button type="button" class="btn btn-danger" onclick="removeBenefit(this)">Remove</button>
                        <?php endif; ?>
                    </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="card-body">
                <div class="form-group row mb-4">
                    <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                    <div class="col-sm-12 col-md-7">
                    <button type="submit" class="btn btn-primary">Update Package</button>
                    </div>
                </div>
            </div>
            
        </form>
    </div>
  </div>
</div>

<script>
    function addBenefit() {
            const div = document.createElement('div');
            div.innerHTML = `
            <div class="form-group row mb-4">
                <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Item</label>
                <div class="col-sm-12 col-md-2">
                    <select class="form-control" name="benefit[${document.querySelectorAll('[name^="benefit["]').length}][type]" required>
                        <option value="include" selected>Include</option>
                        <option value="exclude">Exclude</option>
                    </select>
                </div>
                <div class="col-sm-12 col-md-4">
                    <input type="text" class="form-control" name="benefit[${document.querySelectorAll('[name^="benefit["]').length}][benefit]" required>
                </div>
                <div class="col-sm-12 col-md-2">
                <button type="button" class="btn btn-danger" onclick="removeBenefit(this)">Remove</button>
                </div>
            </div>`;
            document.getElementById('book_fields').appendChild(div);
        }

        function removeBenefit(button) {
            button.parentNode.parentNode.parentNode.removeChild(button.parentNode.parentNode);
        }

        document.getElementById('inputForm').addEventListener('submit', function(event) {
            const inputs = document.querySelectorAll('[name^="benefit["]');
            let atLeastOneFilled = false;
            inputs.forEach(function(input) {
                if (input.value.trim() !== '') {
                    atLeastOneFilled = true;
                }
            });
            if (!atLeastOneFilled) {
                event.preventDefault();
                alert('Setidaknya satu field harus diisi');
            }
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/diginomik/resources/views/admin/package/edit.blade.php ENDPATH**/ ?>