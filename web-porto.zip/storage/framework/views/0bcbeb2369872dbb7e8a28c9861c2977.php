<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Digifolium, mitra tepercaya bagi penjual dan pemilik merek di Indonesia. Dapatkan jasa kelola dan optimasi toko online di berbagai marketplace untuk meningkatkan penjualan produk Anda.">
    <meta name="keywords" content="Optimasi Toko Online, Manajemen Marketplace, Jasa Kelola Toko, Optimalisasi Penjualan">


    <!-- FONT -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/light_logo_1.png')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/main.css')); ?>">

    <!-- PLUGIN -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <title>Website Portfolio Saya</title>
  </head>
  <body>

    <nav class="navbar navbar-expand-lg navbar-light bg-primary-new fixed-top">
        <div class="container">
        <a class="navbar-brand" href="#header">
            <h4>Website Saya</h4>
        </a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="#header" class="nav-link  ml-0 ml-md-4">Home </a>
                </li>
                <li class="nav-item">
                    <a href="#about" class="nav-link  ml-0 ml-md-4" href="#">Tentang Saya</a>
                </li>
                <li class="nav-item">
                    <a href="#skill" class="nav-link  ml-0 ml-md-4" href="#">Skills</a>
                </li>
                <li class="nav-item">
                    <a href="#projects" class="nav-link  ml-0 ml-md-4" href="#">Hasil Kerja</a>
                </li>
                <li class="nav-item">
                    <a href="#certificate" class="nav-link  ml-0 ml-md-4" href="#">Sertifikat</a>
                </li>
                
            </ul>
        </div>
        </div>
    </nav>

    <section id="header" class="section-header" data-aos="fade-up" data-aos-duration="1000">
       <div class="container">
            <div class="row">
                <div class="col-12 col-md-6 text-wrapper">
                    <div class="small-text">Hey, I am Nayla Qanita Alifia 👋 </div>
                    <div class="title">I am a <span style="color : #5E3BEE">Junior Website Developer</span></div>
                    <div class="subtitle">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit quidem assumenda inventore quasi eos dolores quas ducimus soluta, sed voluptate, quaerat rerum dicta quia cupiditate? Deleniti aliquid similique optio doloribus?</div>
                    <a href="#" class="btn btn-get-touch">Get In Touch</a>
                    <div class="logo-wrapper">
                        <a href="https://github.com/">
                            <img class="" src="<?php echo e('assets/images/github.svg'); ?>" alt="">
                        </a>
                        <a href="https://www.instagram.com/">
                            <img class="" src="<?php echo e('assets/images/instagram.svg'); ?>" alt="">
                        </a>
                        <a href="https://www.facebook.com/">
                            <img class="" src="<?php echo e('assets/images/facebook.svg'); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-12 col-md-6 img-wrapper d-none d-md-block">
                    <img src="<?php echo e(asset('assets/images/header.jpg')); ?>" alt="">
                </div>
                
            </div>
       </div>
    </section>

    <section id="about" class="section-about" data-aos="fade-up" data-aos-duration="1000">
       <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="title">Tentang Kami</div>
                    <div class="subtitle">
                        <p>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nesciunt corrupti natus, doloribus eveniet, cumque repudiandae aspernatur, dolor maxime molestiae sequi at cupiditate alias possimus labore quaerat quisquam qui voluptates libero.
                        </p>
                        <p>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nesciunt corrupti natus, doloribus eveniet, cumque repudiandae aspernatur, dolor maxime molestiae sequi at cupiditate alias possimus labore quaerat quisquam qui voluptates libero.
                        </p>
                    </div>
                </div>
            </div>
       </div>
    </section>

    <section id="skill" class="section-skill" data-aos="fade-up" data-aos-duration="1000">
       <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="title">Skills</div>
                </div>
                <div class="col-6 col-md-2 mb-5 img-wrapper">
                    <img src="<?php echo e(asset('assets/images/html.png')); ?>" alt="">
                </div>
                <div class="col-6 col-md-2 mb-5 img-wrapper">
                    <img src="<?php echo e(asset('assets/images/css.png')); ?>" alt="">
                </div>
                <div class="col-6 col-md-2 mb-5 img-wrapper">
                    <img src="<?php echo e(asset('assets/images/js.png')); ?>" alt="">
                </div>
                <div class="col-6 col-md-2 mb-5 img-wrapper">
                    <img src="<?php echo e(asset('assets/images/php.png')); ?>" alt="">
                </div>
                <div class="col-6 col-md-2 mb-5 img-wrapper">
                    <img src="<?php echo e(asset('assets/images/bootstrap.svg')); ?>" alt="">
                </div>
                <div class="col-6 col-md-2 mb-5 img-wrapper">
                    <img src="<?php echo e(asset('assets/images/laravel.png')); ?>" alt="">
                </div>
            </div>
       </div>
    </section>
   

    <section id="projects" class="section-projects" data-aos="fade-up" data-aos-duration="1000">
       <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="title">Hasil Kerja</div>
                </div>
                <div class="col-12 col-md-4 card-project mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/project.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Project CRUD 1</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-project mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/project.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Project CRUD 1</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-project mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/project.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Project CRUD 1</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-project mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/project.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Project CRUD 1</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-project mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/project.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Project CRUD 1</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-project mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/project.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Project CRUD 1</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
            </div>
       </div>
    </section>


    <section id="certificate"  class="section-certificate" data-aos="fade-up" data-aos-duration="1000">
       <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="title">Sertifikat</div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
                <div class="col-12 col-md-4 card-certificate mb-5">
                    <div class="img-wrapper">
                    <img src="<?php echo e(asset('assets/images/certificate.jpeg')); ?>" alt="">
                    </div>
                    <div class="text-wrapper">
                        <div class="project">Sertifikat 1</div>
                        <div class="year">10 Jun 2024</div>
                        <div class="desc">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Illo accusantium quia tempore deserunt sit quisquam enim, libero obcaecati amet pariatur dolor, explicabo eum numquam voluptatum placeat, minus omnis voluptatem est?</div>
                    </div>
                </div>
            </div>
       </div>
    </section>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <!-- PLUGIN -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <script>
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            const target = document.querySelector(this.getAttribute('href'));
            const offset = 100; // Atur offset margin atas yang diinginkan di sini

            window.scrollTo({
                top: target.offsetTop - offset,
                behavior: 'smooth'
            });
        });
    });
</script>
  </body>
</html><?php /**PATH /Applications/MAMP/htdocs/diginomik/resources/views/home.blade.php ENDPATH**/ ?>