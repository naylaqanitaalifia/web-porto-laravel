<?php $__env->startSection('header'); ?>
	<div class="section-header">
    <h1>Edit Blog</h1>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <a href="<?php echo e(route('blog.index')); ?>" class="btn btn-warning">Kembali ke Blog List</a>
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('blog.update',$data->id)); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
          <div class="form-group row mb-4">
            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Image Thumbnail</label>
            <div class="col-sm-12 col-md-7">
              <input type="file" class="form-control" name="img">
                <?php if($data->img): ?>
                <img src="<?php echo e(asset('upload/'.$data->img)); ?>" alt="Gambar" width="150">
                <?php else: ?>
                    <p>Tidak ada gambar tersedia</p>
                <?php endif; ?>
            </div>
          </div>

          <div class="form-group row mb-4">
            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Title</label>
            <div class="col-sm-12 col-md-7">
              <input type="text" class="form-control" name="title" required  value="<?php echo e($data->title); ?>">
            </div>
          </div>

          <div class="form-group row mb-4">
            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Content</label>
            <div class="col-sm-12 col-md-7">
              <textarea name="content" class="form-control" cols="30" rows="10" id="editor" >
              <?php echo e($data->content); ?>

              </textarea>
            </div>
          </div>

          <div class="form-group row mb-4">
            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Status</label>
            <div class="col-sm-12 col-md-7">
            <select class="form-control" name="status">
                    <?php if($data->status == 'active'): ?>
                        <option value="active" selected>Active</option>
                        <option value="unactive">Unactive</option>
                    <?php elseif($data->status == 'unactive'): ?>
                        <option value="active">Active</option>
                        <option value="unactive" selected>Unactive</option>
                    <?php endif; ?>
                </select>
            </div>
            </div>
          </div>

          <div class="form-group row mb-4">
            <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
            <div class="col-sm-12 col-md-7">
              <button type="submit" class="btn btn-primary">Update blog</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/diginomik/resources/views/admin/blog/edit.blade.php ENDPATH**/ ?>