<?php $__env->startSection('header'); ?>
	<div class="section-header">
    <h1>Package</h1>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="section-table-package-list">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                <div class="btn-wrapper">
                <a href="<?php echo e(route('package.create')); ?>" class="btn btn-primary">Tambah Package</a>
                <br><br>    
                </div>
                <div class="table-responsive">
                <table class="table table-striped table-blog">
                        <tr>
                            <th>Title</th>
                            <th>Subtitle</th>
                            <th>Harga</th>
                            <th>Discount</th>
                            <th>Harga Final</th>
                            <th>Total Benefit</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->subtitle); ?></td>
                            <td>Rp<?php echo e(number_format($item->price)); ?></td>
                            <td><?php echo e($item->discount); ?> %</td>
                            <td>Rp<?php echo e(number_format($item->final_price)); ?></td>
                            <td>
                                <?php
                                    $count_benefit = App\Models\Benefit::where('package_id',$item->id)->count();
                                ?>
                                <?php echo e($count_benefit); ?>

                            </td>
                            <td>
                                <?php if($item->status == 'active'): ?>
                                    <div class="badge badge-primary">Active</div>
                                <?php elseif($item->status == 'unactive'): ?>
                                    <div class="badge badge-danger">Unactive</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('package.edit',$item->id)); ?>" class="btn btn-info">
                                        <i class="far fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('package.delete',$item->id)); ?>" method="post" id="confirmDelete">
                                        <?php echo csrf_field(); ?> 
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" href="#" class="btn btn-danger delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    <a href="<?php echo e(route('package.show',$item->id)); ?>" class="btn btn-info">
                                        <i class="far fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No package available</td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/diginomik/resources/views/admin/package/index.blade.php ENDPATH**/ ?>